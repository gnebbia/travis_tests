===============================
{{ cookiecutter.project_name }}
===============================

.. toctree::
   :maxdepth: 2

   README for {{ cookiecutter.project_name }} <README>
   CONTRIBUTING
   LICENSE
   CHANGELOG

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
