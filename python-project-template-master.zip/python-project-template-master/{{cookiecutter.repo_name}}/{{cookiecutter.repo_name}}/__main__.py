# -*- encoding: utf-8 -*-
# {{ cookiecutter.project_name }} v{{ cookiecutter.version }}
# {{ cookiecutter.project_short_description }}
# Copyright © {{ cookiecutter.year }}, {{ cookiecutter.full_name }}.
# See /LICENSE for licensing information.

"""
Main routine of {{ cookiecutter.project_name }}.

:Copyright: © {{ cookiecutter.year }}, {{ cookiecutter.full_name }}.
:License: BSD (see /LICENSE).
"""

__all__ = ('main',)


def main():
    """Main routine of {{ cookiecutter.project_name }}."""
    print("Hello, world!")
    print("This is {{ cookiecutter.project_name }}.")
    print("You should customize __main__.py to your liking (or delete it).")


if __name__ == '__main__':
    main()
