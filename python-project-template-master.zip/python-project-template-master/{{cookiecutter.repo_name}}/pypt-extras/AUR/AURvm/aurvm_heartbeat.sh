#!/bin/sh
echo "AURvm OK"
