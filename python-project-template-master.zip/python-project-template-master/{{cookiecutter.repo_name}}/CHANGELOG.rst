=====================
Appendix C. Changelog
=====================
:Info: This is the changelog for {{ cookiecutter.project_name }}.
:Author: {{ cookiecutter.full_name }} <{{ cookiecutter.email }}>
:Copyright: © {{ cookiecutter.year }}, {{ cookiecutter.full_name }}.
:License: BSD (see /LICENSE or :doc:`Appendix B <LICENSE>`.)
:Date: {{ cookiecutter.release_date }}
:Version: {{ cookiecutter.version }}

.. index:: CHANGELOG

GitHub holds releases, too
==========================

More information can be found on GitHub in the `releases section
<https://github.com/{{ cookiecutter.github_username }}/{{ cookiecutter.repo_name }}/releases>`_.

Version History
===============

0.1.0
    Initial release.
